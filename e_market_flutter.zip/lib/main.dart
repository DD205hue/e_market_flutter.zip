import 'package:flutter/material.dart';
import 'screens/home.dart';
import 'screens/login.dart';
import 'screens/seller_dashboard.dart';

void main() {
  runApp(const EMarketApp());
}

class EMarketApp extends StatelessWidget {
  const EMarketApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'E Market',
      theme: ThemeData.dark(),
      debugShowCheckedModeBanner: false,
      initialRoute: '/',
      routes: {
        '/': (context) => const LoginScreen(),
        '/home': (context) => const HomeScreen(),
        '/seller': (context) => const SellerDashboard(),
      },
    );
  }
}
